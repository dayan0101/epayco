CHANGELOG
=========

4.1.0
-----

 * Added the `server:dump` command to run a server collecting and displaying
   dumps on a single place with multiple formats support
