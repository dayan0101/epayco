# Code of Conduct

This project follows a [Code of Conduct][code_of_conduct] in order to ensure an open and welcoming environment.
Please read the full text for understanding the accepted and unaccepted behavior.
Please read also the [reporting guidelines][guidelines], in case you encountered or witnessed any misbehavior.

[code_of_conduct]: https://symfony.com/doc/current/contributing/code_of_conduct/index.html
[guidelines]: https://symfony.com/doc/current/contributing/code_of_conduct/reporting_guidelines.html
