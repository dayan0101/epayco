---
name: ⛔ Support Question
about: See https://symfony.com/support for questions about using Symfony and its components

---

We use GitHub issues only to discuss about Symfony bugs and new features. For
this kind of questions about using Symfony or third-party bundles, please use
any of the support alternatives shown in https://symfony.com/support

Thanks!
